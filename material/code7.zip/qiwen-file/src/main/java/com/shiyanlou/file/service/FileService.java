package com.shiyanlou.file.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shiyanlou.file.model.File;

public interface FileService extends IService<File> {

}