package com.shiyanlou.file.mapper;

public interface UserfileMapper {
    
}
